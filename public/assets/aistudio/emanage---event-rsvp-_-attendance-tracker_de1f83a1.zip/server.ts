import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Public shared URL calculation
const rawAppUrl = process.env.APP_URL || '';
// Ensure public URL replaces ais-dev- with ais-pre- for publicly accessible links
const sharedAppUrl = rawAppUrl.replace('ais-dev-', 'ais-pre-');

// Persisted events database directory
const DATA_DIR = path.resolve(__dirname, 'data');
const DB_FILE = path.resolve(DATA_DIR, 'db.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface DbData {
  events: any[];
  rsvpResponses: any[];
}

let dbData: DbData = {
  events: [],
  rsvpResponses: []
};

if (fs.existsSync(DB_FILE)) {
  try {
    dbData = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  } catch (e) {
    console.error('Error reading db.json', e);
  }
}

const saveDb = () => {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(dbData, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error writing db.json', e);
  }
};

// API: Public configuration and base URLs
app.get('/api/config', (_req, res) => {
  res.json({
    appUrl: rawAppUrl,
    sharedAppUrl: sharedAppUrl || rawAppUrl,
  });
});

// API: Get all events
app.get('/api/events', (_req, res) => {
  res.json(dbData.events || []);
});

// API: Get single event by id
app.get('/api/events/:id', (req, res) => {
  const event = dbData.events.find((e: any) => e.id === req.params.id);
  if (!event) {
    return res.status(404).json({ error: 'Event not found' });
  }
  res.json(event);
});

// API: Sync events from organizer dashboard
app.post('/api/events/sync', (req, res) => {
  const { events } = req.body;
  if (Array.isArray(events)) {
    for (const ev of events) {
      const idx = dbData.events.findIndex((e: any) => e.id === ev.id);
      if (idx >= 0) {
        dbData.events[idx] = { ...dbData.events[idx], ...ev };
      } else {
        dbData.events.push(ev);
      }
    }
    saveDb();
  }
  res.json({ success: true, count: dbData.events.length, events: dbData.events });
});

// Helper to normalize RSVP input strings from Google Forms/Sheets
function normalizeRsvpStatus(raw: string | undefined): 'Confirmed' | 'Declined' | 'Pending' {
  if (!raw) return 'Pending';
  const clean = raw.trim().toLowerCase();
  if (
    clean.includes('confirm') ||
    clean.includes('attending') ||
    clean.includes('yes') ||
    clean.includes('going') ||
    clean.includes('pupunta') ||
    clean.includes('oo') ||
    clean === 'attend'
  ) {
    return 'Confirmed';
  }
  if (
    clean.includes('declin') ||
    clean.includes('cannot') ||
    clean.includes("can't") ||
    clean.includes('not attending') ||
    clean.includes('no') ||
    clean.includes('hindi') ||
    clean === 'absent'
  ) {
    return 'Declined';
  }
  return 'Pending';
}

// API: Submit RSVP from guest phone or laptop
app.post('/api/rsvp', (req, res) => {
  const { eventId, guestName, guestEmail, rsvp, notes, eventDetails } = req.body;
  if (!eventId || !guestName || !guestEmail) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const normalizedRsvp = normalizeRsvpStatus(rsvp);

  let event = dbData.events.find((e: any) => e.id === eventId);
  if (!event && eventDetails) {
    event = {
      id: eventId,
      title: eventDetails.title || 'Untitled Event',
      desc: eventDetails.desc || '',
      date: eventDetails.date || new Date().toISOString().slice(0, 10),
      time: eventDetails.time || '9:00 am',
      location: eventDetails.location || 'Main Venue',
      month_display: eventDetails.month_display || 'October 2026',
      day_display: eventDetails.day_display || 'Oct\n05',
      max_guests: Number(eventDetails.max_guests) || 50,
      rsvp_count: 0,
      status: 'Upcoming',
      rsvp_link: 'https://forms.gle/aFGNLexpupZkvvpr8',
      guests: []
    };
    dbData.events.push(event);
  }

  if (event) {
    if (!Array.isArray(event.guests)) {
      event.guests = [];
    }

    const existingGuestIdx = event.guests.findIndex(
      (g: any) => g.email.toLowerCase() === guestEmail.toLowerCase() || g.name.toLowerCase() === guestName.toLowerCase()
    );

    const guestObj = {
      id: existingGuestIdx >= 0 ? event.guests[existingGuestIdx].id : 'g_' + Math.random().toString(36).substring(2, 9),
      name: guestName,
      email: guestEmail,
      invited: true,
      rsvp: normalizedRsvp,
      attendance: normalizedRsvp === 'Confirmed' ? 'Attended' : 'Absent',
      notes: notes || ''
    };

    if (existingGuestIdx >= 0) {
      event.guests[existingGuestIdx] = guestObj;
    } else {
      event.guests.push(guestObj);
    }

    event.rsvp_count = event.guests.filter((g: any) => g.rsvp === 'Confirmed').length;
    saveDb();

    return res.json({ success: true, guest: guestObj, event });
  }

  // Also log raw response
  dbData.rsvpResponses.push({
    eventId,
    guestName,
    guestEmail,
    rsvp: normalizedRsvp,
    notes,
    timestamp: new Date().toISOString()
  });
  saveDb();

  res.json({ success: true });
});

// API: Google Form Webhook / Apps Script endpoint
// Connected directly to Google Form submissions for real-time guest list updates
app.all('/api/gform-webhook', (req, res) => {
  const query = req.query || {};
  const body = req.body || {};

  // Find target event ID from query or body
  const eventId = (query.eventId || body.eventId || query.id || body.id || '').toString();

  // Find guest name from various Google Forms question labels
  const guestName = (
    body.name ||
    body.guestName ||
    body['Full Name'] ||
    body['Name'] ||
    body['Pangalan'] ||
    query.name ||
    query.guestName ||
    ''
  ).toString().trim();

  // Find guest email
  const guestEmail = (
    body.email ||
    body.guestEmail ||
    body['Email Address'] ||
    body['Email'] ||
    query.email ||
    query.guestEmail ||
    ''
  ).toString().trim();

  // Find RSVP status
  const rawRsvp = (
    body.rsvp ||
    body.status ||
    body['Will you attend?'] ||
    body['RSVP'] ||
    body['Confirmation'] ||
    body['Attendance'] ||
    body['Response'] ||
    query.rsvp ||
    query.status ||
    ''
  ).toString();

  const notes = (
    body.notes ||
    body.message ||
    body['Notes'] ||
    body['Message'] ||
    query.notes ||
    ''
  ).toString();

  if (!guestName) {
    return res.status(400).json({ error: 'Missing guest name in form submission' });
  }

  const normalizedRsvp = normalizeRsvpStatus(rawRsvp);

  // If specific eventId is provided, find it; otherwise default to the latest/first event
  let event = eventId ? dbData.events.find((e: any) => e.id === eventId) : dbData.events[0];

  if (!event) {
    event = {
      id: eventId || 'evt_' + Math.random().toString(36).substring(2, 9),
      title: 'Google Form Event',
      desc: 'Created via Google Form submissions',
      date: new Date().toISOString().slice(0, 10),
      time: '9:00 am',
      location: 'Venue',
      month_display: 'October 2026',
      day_display: 'Oct\n05',
      max_guests: 50,
      rsvp_count: 0,
      status: 'Upcoming',
      rsvp_link: 'https://forms.gle/aFGNLexpupZkvvpr8',
      guests: []
    };
    dbData.events.push(event);
  }

  if (!Array.isArray(event.guests)) {
    event.guests = [];
  }

  const existingGuestIdx = event.guests.findIndex(
    (g: any) =>
      (guestEmail && g.email.toLowerCase() === guestEmail.toLowerCase()) ||
      g.name.toLowerCase() === guestName.toLowerCase()
  );

  const guestObj = {
    id: existingGuestIdx >= 0 ? event.guests[existingGuestIdx].id : 'g_' + Math.random().toString(36).substring(2, 9),
    name: guestName,
    email: guestEmail || `${guestName.toLowerCase().replace(/\s+/g, '.')}@guest.com`,
    invited: true,
    rsvp: normalizedRsvp,
    attendance: normalizedRsvp === 'Confirmed' ? 'Attended' : 'Absent',
    notes: notes || (existingGuestIdx >= 0 ? event.guests[existingGuestIdx].notes : '')
  };

  if (existingGuestIdx >= 0) {
    event.guests[existingGuestIdx] = guestObj;
  } else {
    event.guests.unshift(guestObj);
  }

  event.rsvp_count = event.guests.filter((g: any) => g.rsvp === 'Confirmed').length;
  saveDb();

  const stats = {
    total: event.guests.length,
    confirmed: event.guests.filter((g: any) => g.rsvp === 'Confirmed').length,
    declined: event.guests.filter((g: any) => g.rsvp === 'Declined').length,
    pending: event.guests.filter((g: any) => g.rsvp === 'Pending').length
  };

  res.json({
    success: true,
    message: `Recorded ${guestName} (${normalizedRsvp}) to guest list`,
    guest: guestObj,
    stats,
    event
  });
});

// API: Sync Google Form responses directly from linked Google Sheet
app.post('/api/sync-gform-sheet', async (req, res) => {
  const { eventId, sheetUrl } = req.body;
  if (!eventId || !sheetUrl) {
    return res.status(400).json({ error: 'Missing eventId or sheetUrl' });
  }

  const event = dbData.events.find((e: any) => e.id === eventId);
  if (!event) {
    return res.status(404).json({ error: 'Event not found' });
  }

  try {
    // Transform standard Google Sheet URL to public CSV export URL
    let exportUrl = sheetUrl.trim();
    const sheetIdMatch = exportUrl.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (sheetIdMatch && sheetIdMatch[1]) {
      const docId = sheetIdMatch[1];
      exportUrl = `https://docs.google.com/spreadsheets/d/${docId}/export?format=csv`;
    }

    const response = await fetch(exportUrl);
    if (!response.ok) {
      return res.status(400).json({
        error: `Could not fetch Google Sheet CSV (Status: ${response.status}). Please make sure "Anyone with the link can view" is enabled.`
      });
    }

    const csvText = await response.text();
    const lines = csvText.split('\n').map((l: string) => l.trim()).filter(Boolean);

    if (lines.length < 2) {
      return res.json({ success: true, count: 0, message: 'No responses found in sheet yet' });
    }

    const headerParts = lines[0].split(',').map((h: string) => h.trim().replace(/^["']|["']$/g, '').toLowerCase());

    // Detect column indexes
    let nameIdx = headerParts.findIndex((h: string) => h.includes('name') || h.includes('pangalan'));
    let emailIdx = headerParts.findIndex((h: string) => h.includes('email') || h.includes('mail'));
    let rsvpIdx = headerParts.findIndex(
      (h: string) => h.includes('attend') || h.includes('rsvp') || h.includes('confirm') || h.includes('status')
    );

    // Fallbacks if columns are standard position
    if (nameIdx === -1 && lines[0].split(',').length >= 2) nameIdx = 1;
    if (emailIdx === -1 && lines[0].split(',').length >= 3) emailIdx = 2;
    if (rsvpIdx === -1 && lines[0].split(',').length >= 4) rsvpIdx = 3;

    if (!Array.isArray(event.guests)) {
      event.guests = [];
    }

    let addedCount = 0;
    let updatedCount = 0;

    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(',').map((c: string) => c.trim().replace(/^["']|["']$/g, ''));
      const name = nameIdx >= 0 ? cols[nameIdx] : cols[1];
      if (!name) continue;

      const email = emailIdx >= 0 && cols[emailIdx] ? cols[emailIdx] : `${name.toLowerCase().replace(/\s+/g, '.')}@guest.com`;
      const rawRsvp = rsvpIdx >= 0 ? cols[rsvpIdx] : 'Confirmed';
      const normalizedRsvp = normalizeRsvpStatus(rawRsvp);

      const existingIdx = event.guests.findIndex(
        (g: any) =>
          (email && g.email.toLowerCase() === email.toLowerCase()) ||
          g.name.toLowerCase() === name.toLowerCase()
      );

      const guestObj = {
        id: existingIdx >= 0 ? event.guests[existingIdx].id : 'g_' + Math.random().toString(36).substring(2, 9),
        name,
        email,
        invited: true,
        rsvp: normalizedRsvp,
        attendance: normalizedRsvp === 'Confirmed' ? 'Attended' : 'Absent',
        notes: 'Synced from Google Form Sheet'
      };

      if (existingIdx >= 0) {
        event.guests[existingIdx] = guestObj;
        updatedCount++;
      } else {
        event.guests.push(guestObj);
        addedCount++;
      }
    }

    event.rsvp_count = event.guests.filter((g: any) => g.rsvp === 'Confirmed').length;
    saveDb();

    return res.json({
      success: true,
      addedCount,
      updatedCount,
      totalGuests: event.guests.length,
      confirmed: event.guests.filter((g: any) => g.rsvp === 'Confirmed').length,
      declined: event.guests.filter((g: any) => g.rsvp === 'Declined').length,
      pending: event.guests.filter((g: any) => g.rsvp === 'Pending').length,
      event
    });
  } catch (err: any) {
    console.error('Error syncing Google Sheet:', err);
    return res.status(500).json({ error: err.message || 'Failed to sync Google Sheet' });
  }
});

// API: Update Event RSVP Link
app.post('/api/events/:id/rsvp-link', (req, res) => {
  const { rsvp_link } = req.body;
  const event = dbData.events.find((e: any) => e.id === req.params.id);
  if (!event) {
    return res.status(404).json({ error: 'Event not found' });
  }
  event.rsvp_link = rsvp_link || 'https://forms.gle/aFGNLexpupZkvvpr8';
  saveDb();
  res.json({ success: true, event });
});

// Start Server with Vite Middleware
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EManage Fullstack Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
